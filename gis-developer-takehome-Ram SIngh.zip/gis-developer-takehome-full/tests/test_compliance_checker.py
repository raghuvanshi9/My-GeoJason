
<full content of test_compliance_checker.py from earlier here>
