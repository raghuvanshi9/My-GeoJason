
<full content of test_arcgis_client.py from earlier here>
