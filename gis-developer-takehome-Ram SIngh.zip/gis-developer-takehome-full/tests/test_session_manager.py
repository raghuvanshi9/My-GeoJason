
<full content of test_session_manager.py from earlier here>
